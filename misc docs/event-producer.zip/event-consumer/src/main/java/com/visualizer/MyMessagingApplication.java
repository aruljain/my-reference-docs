package com.visualizer;

import com.visualizer.model.Event;
import jakarta.enterprise.context.ApplicationScoped;
import org.eclipse.microprofile.reactive.messaging.Incoming;
import org.jboss.logging.Logger;

@ApplicationScoped
public class MyMessagingApplication {

    private static final Logger LOG = Logger.getLogger(MyMessagingApplication.class);

    /**
     * Reads from the "events-in" channel, which is configured in
     * application.properties to use
     * io.apicurio.registry.serde.avro.AvroKafkaDeserializer with
     * use-specific-avro-reader=true. The schema is resolved automatically
     * from Apicurio Registry based on the ID embedded in the message, so by
     * the time this method runs, `event` is already a fully-deserialized
     * Event object.
     */
    @Incoming("events-in")
    public void consume(Event event) {
        LOG.infof("Received event: id=%s type=%s message=%s ",
                event.getEventId(), event.getEventType(), event.getMessage());
    }
}

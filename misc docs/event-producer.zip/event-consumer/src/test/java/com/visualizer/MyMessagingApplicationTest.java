package com.visualizer;

import com.visualizer.model.Event;
import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;
import org.junit.jupiter.api.Test;

@QuarkusTest
class MyMessagingApplicationTest {

    @Inject
    MyMessagingApplication application;

    @Test
    void consumeDoesNotThrow() {
        Event event = Event.newBuilder()
                .setEventId("test-id")
                .setEventType("TEST")
                .setMessage("hello")
                .build();

        // Just verifies the @Incoming handler runs cleanly against a
        // well-formed Event; full broker round-trip is covered by an
        // integration test against a real/dev-services Kafka + Registry.
        application.consume(event);
    }
}

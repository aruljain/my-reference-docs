package com.visualizer;

import com.visualizer.model.Event;
import io.quarkus.test.junit.QuarkusTest;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@QuarkusTest
class MyMessagingApplicationTest {

    @Test
    void buildEventPopulatesAllFields() {
        Event event = MyMessagingApplication.buildEvent("DEMO", "Hello","In Progress");

        assertNotNull(event.getEventId());
        assertEquals("DEMO", event.getEventType().toString());
        assertEquals("Hello", event.getMessage().toString());
        assertEquals("In Progress", event.getStatus().toString());
    }
}

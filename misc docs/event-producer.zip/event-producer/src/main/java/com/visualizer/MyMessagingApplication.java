package com.visualizer;

import com.visualizer.model.Event;
import io.quarkus.runtime.StartupEvent;
import io.smallrye.reactive.messaging.MutinyEmitter;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.event.Observes;
import jakarta.inject.Inject;
import org.eclipse.microprofile.reactive.messaging.Channel;

import java.util.UUID;
import java.util.stream.Stream;

@ApplicationScoped
public class MyMessagingApplication {

    /**
     * Injects an emitter to send Avro-encoded Event records to the
     * "events-out" channel. See application.properties for the wiring to
     * io.apicurio.registry.serde.avro.AvroKafkaSerializer.
     */
    @Inject
    @Channel("events-out")
    MutinyEmitter<Event> emitter;

    /**
     * Fires a few demo events on startup so you can see the pipeline work
     * end to end without needing to call the REST endpoint first.
     */
    void onStart(@Observes StartupEvent ev) {
        Stream.of("Hello", "with", "Quarkus", "Messaging", "Avro")
                .forEach(word -> emitter.sendAndAwait(buildEvent("DEMO", word,"In Progress")));
    }

    public static Event buildEvent(String eventType, String message, String status) {
        return Event.newBuilder()
                .setEventId(UUID.randomUUID().toString())
                .setEventType(eventType)
                .setMessage(message)
                .setStatus(status)
                .build();
    }
}
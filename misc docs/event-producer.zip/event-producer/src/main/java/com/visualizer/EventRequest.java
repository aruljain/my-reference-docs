package com.visualizer;

public class EventRequest {

    public String eventType;
    public String message;
    public String status;
}

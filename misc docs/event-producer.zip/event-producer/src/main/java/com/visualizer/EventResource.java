package com.visualizer;

import org.eclipse.microprofile.reactive.messaging.Channel;

import io.smallrye.reactive.messaging.MutinyEmitter;
import jakarta.inject.Inject;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.core.MediaType;
import com.visualizer.model.Event;

@Path("/events")
public class EventResource {

    @Inject
    @Channel("events-out")
    MutinyEmitter<Event> emitter;

    /**
     * POST /events  { "eventType": "ORDER_CREATED", "message": "order #42" }
     *
     * Builds an Avro Event and sends it via the "events-out" channel, which
     * is configured to use AvroKafkaSerializer against Apicurio Registry.
     */
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public String produce(EventRequest request) {
        Event event = MyMessagingApplication.buildEvent(request.eventType, request.message, request.status);
        emitter.sendAndAwait(event);
        return "sent eventId=" + event.getEventId();
    }
}

rootProject.name = "avro-event-scanner"

package com.yourcompany.avroscanner

import com.intellij.notification.NotificationGroupManager
import com.intellij.notification.NotificationType
import com.intellij.openapi.actionSystem.AnAction
import com.intellij.openapi.actionSystem.AnActionEvent
import com.intellij.openapi.application.ApplicationManager
import com.intellij.openapi.application.WriteAction
import com.intellij.openapi.progress.ProgressIndicator
import com.intellij.openapi.progress.ProgressManager
import com.intellij.openapi.progress.Task
import com.intellij.openapi.project.Project
import com.intellij.openapi.ui.Messages
import com.intellij.openapi.vfs.LocalFileSystem
import com.intellij.openapi.vfs.VfsUtil
import java.io.File

class GenerateAvroSchemasAction : AnAction() {

    override fun actionPerformed(e: AnActionEvent) {
        val project = e.project ?: return

        ProgressManager.getInstance().run(object : Task.Backgroundable(project, "Scanning for Kafka event classes", true) {
            override fun run(indicator: ProgressIndicator) {
                indicator.text = "Finding Kafka producer/consumer payload types..."

                val candidates = ApplicationManager.getApplication().runReadAction<Set<com.intellij.psi.PsiClass>> {
                    KafkaEventDetector.detectCandidates(project)
                }

                if (candidates.isEmpty()) {
                    notify(project, "No Kafka event payload classes were found. " +
                            "Check that @Incoming/@Outgoing methods, Emitter<T> fields, or KafkaProducer/Consumer<K,V> " +
                            "usages exist and that the project has indexed successfully.", NotificationType.WARNING)
                    return
                }

                indicator.text = "Generating draft .avsc schemas for ${candidates.size} classes..."

                val generated = ApplicationManager.getApplication().runReadAction<List<GeneratedSchema>> {
                    candidates.map { AvroSchemaGenerator.generate(it) }
                }

                val outputDir = File(project.basePath, "src/main/avro").apply { mkdirs() }

                WriteAction.runAndWait<RuntimeException> {
                    val vDir = VfsUtil.createDirectoryIfMissing(outputDir.absolutePath)
                    generated.forEach { schema ->
                        val file = File(outputDir, "${schema.artifactName}.avsc")
                        file.writeText(schema.json)
                    }
                    vDir?.refresh(false, true)
                    LocalFileSystem.getInstance().refreshAndFindFileByIoFile(outputDir)
                }

                showSummary(project, generated, outputDir.absolutePath)
            }
        })
    }

    private fun showSummary(project: Project, generated: List<GeneratedSchema>, outputPath: String) {
        val totalWarnings = generated.sumOf { it.warnings.size }
        val body = buildString {
            append("Generated ${generated.size} draft .avsc file(s) to:\n$outputPath\n\n")
            append("Classes: ${generated.joinToString(", ") { it.artifactName }}\n\n")
            if (totalWarnings > 0) {
                append("$totalWarnings item(s) need manual review before these schemas are trustworthy:\n\n")
                generated.forEach { schema ->
                    if (schema.warnings.isNotEmpty()) {
                        append("• ${schema.artifactName}:\n")
                        schema.warnings.forEach { append("   - $it\n") }
                    }
                }
            } else {
                append("No review flags were raised, but you should still sanity-check field types and nullability.")
            }
        }

        ApplicationManager.getApplication().invokeLater {
            Messages.showInfoMessage(project, body, "Avro Schema Generation Complete")
        }
    }

    private fun notify(project: Project, message: String, type: NotificationType) {
        NotificationGroupManager.getInstance()
            .getNotificationGroup("Avro Event Scanner")
            .createNotification(message, type)
            .notify(project)
    }
}

package com.yourcompany.avroscanner

import com.intellij.openapi.project.Project
import com.intellij.psi.*
import com.intellij.psi.search.FileTypeIndex
import com.intellij.psi.search.GlobalSearchScope
import com.intellij.psi.util.PsiTreeUtil
import com.intellij.ide.highlighter.JavaFileType

/**
 * Finds candidate Kafka event payload classes by looking at *structural* usage points
 * rather than naming conventions or custom annotations:
 *
 *  - @Incoming / @Outgoing annotated methods (SmallRye Reactive Messaging)
 *  - Emitter<T> / MutinyEmitter<T> fields (typically paired with @Channel)
 *  - KafkaProducer<K,V> / KafkaConsumer<K,V> fields, params, locals
 *  - ProducerRecord<K,V> / ConsumerRecord<K,V> usages
 *
 * Wrapper generics (Message<T>, Uni<T>, Multi<T>, List<T>, Optional<T>,
 * CompletionStage<T>) are unwrapped to find the real payload type.
 */
object KafkaEventDetector {

    private val WRAPPER_SIMPLE_NAMES = setOf(
        "Message", "Uni", "Multi", "List", "Optional", "CompletionStage", "Set"
    )

    // Packages we never consider "domain" event classes even if they show up as a generic arg.
    private val EXCLUDED_PACKAGE_PREFIXES = listOf(
        "java.", "javax.", "jakarta.",
        "org.apache.kafka.", "io.smallrye.", "io.vertx.", "org.eclipse.microprofile.",
        "com.fasterxml.jackson.", "kotlin.", "reactor."
    )

    fun detectCandidates(project: Project): Set<PsiClass> {
        val results = LinkedHashSet<PsiClass>()
        val scope = GlobalSearchScope.projectScope(project)
        val psiManager = PsiManager.getInstance(project)

        val javaFiles = FileTypeIndex.getFiles(JavaFileType.INSTANCE, scope)

        for (vFile in javaFiles) {
            val psiFile = psiManager.findFile(vFile) as? PsiJavaFile ?: continue
            for (psiClass in psiFile.classes) {
                scanClass(psiClass, results)
            }
        }
        return results
    }

    private fun scanClass(psiClass: PsiClass, results: MutableSet<PsiClass>) {
        // Inner/nested classes too (Quarkus apps often nest small config/listener classes)
        for (inner in psiClass.innerClasses) {
            scanClass(inner, results)
        }

        for (method in psiClass.methods) {
            val hasIncoming = method.hasAnnotationSimpleName("Incoming")
            val hasOutgoing = method.hasAnnotationSimpleName("Outgoing")

            if (hasIncoming) {
                method.parameterList.parameters.firstOrNull()?.type?.let {
                    addIfCandidate(unwrapPayloadType(it), results)
                }
            }
            if (hasOutgoing) {
                addIfCandidate(unwrapPayloadType(method.returnType), results)
            }
        }

        for (field in psiClass.fields) {
            inspectTypeForKafkaGenerics(field.type, results)
        }

        // Local variables and parameters inside method bodies (manual KafkaProducer usage)
        for (method in psiClass.methods) {
            method.parameterList.parameters.forEach { inspectTypeForKafkaGenerics(it.type, results) }
            method.body?.let { body ->
                val locals = PsiTreeUtil.findChildrenOfType(body, PsiLocalVariable::class.java)
                for (local in locals) {
                    inspectTypeForKafkaGenerics(local.type, results)
                }
            }
        }
    }

    private fun inspectTypeForKafkaGenerics(type: PsiType, results: MutableSet<PsiClass>) {
        val classType = type as? PsiClassType ?: return
        val resolved = classType.resolve() ?: return
        val simpleName = resolved.name ?: return

        when (simpleName) {
            "Emitter", "MutinyEmitter" -> {
                classType.parameters.firstOrNull()?.let { addIfCandidate(it, results) }
            }
            "KafkaProducer", "KafkaConsumer", "ProducerRecord", "ConsumerRecord" -> {
                // second type parameter is the value/payload type
                classType.parameters.getOrNull(1)?.let { addIfCandidate(unwrapPayloadType(it), results) }
            }
        }
    }

    /** Unwraps common reactive/collection wrapper generics to find the real payload type. */
    private fun unwrapPayloadType(type: PsiType?): PsiType? {
        var current = type
        var guard = 0
        while (current is PsiClassType && guard < 5) {
            guard++
            val resolved = current.resolve() ?: break
            val name = resolved.name
            if (name != null && name in WRAPPER_SIMPLE_NAMES) {
                current = current.parameters.firstOrNull() ?: return current
            } else {
                break
            }
        }
        return current
    }

    private fun addIfCandidate(type: PsiType?, results: MutableSet<PsiClass>) {
        val classType = type as? PsiClassType ?: return
        val resolved = classType.resolve() ?: return
        if (isExcluded(resolved)) return
        if (resolved.isEnum) return // enums are fields within events, not events themselves
        results.add(resolved)
    }

    private fun isExcluded(psiClass: PsiClass): Boolean {
        val qName = psiClass.qualifiedName ?: return true
        if (qName == "java.lang.String") return true
        return EXCLUDED_PACKAGE_PREFIXES.any { qName.startsWith(it) }
    }

    private fun PsiModifierListOwner.hasAnnotationSimpleName(simpleName: String): Boolean {
        return this.annotations.any { it.qualifiedName?.endsWith(".$simpleName") == true || it.qualifiedName == simpleName }
    }
}

package com.yourcompany.avroscanner

import com.intellij.psi.*

data class GeneratedSchema(
    val artifactName: String,
    val json: String,
    val warnings: List<String>
)

/**
 * Produces a DRAFT .avsc from a PsiClass's fields (or record components).
 * This is a starting point, not a final answer -- nullability, logical types,
 * and enum-vs-string choices still need a human review pass, as flagged in `warnings`.
 */
object AvroSchemaGenerator {

    fun generate(psiClass: PsiClass): GeneratedSchema {
        val warnings = mutableListOf<String>()
        val visited = mutableSetOf<String>() // guards against self-referential / cyclic types
        val fieldsJson = buildFieldsJson(psiClass, warnings, visited, depth = 0)

        val namespace = (psiClass.qualifiedName ?: psiClass.name ?: "unknown")
            .substringBeforeLast('.', missingDelimiterValue = "")
        val name = psiClass.name ?: "UnknownEvent"

        val json = buildString {
            append("{\n")
            append("  \"type\": \"record\",\n")
            append("  \"name\": \"$name\",\n")
            if (namespace.isNotBlank()) append("  \"namespace\": \"$namespace\",\n")
            append("  \"fields\": [\n")
            append(fieldsJson)
            append("\n  ]\n")
            append("}\n")
        }

        return GeneratedSchema(artifactName = name, json = json, warnings = warnings)
    }

    private fun buildFieldsJson(
        psiClass: PsiClass,
        warnings: MutableList<String>,
        visited: MutableSet<String>,
        depth: Int
    ): String {
        val members: List<Pair<String, PsiType>> = when {
            psiClass.isRecord -> psiClass.recordComponents.map { it.name to it.type }
            else -> psiClass.fields
                .filter { !it.hasModifierProperty(PsiModifier.STATIC) }
                .map { it.name to it.type }
        }

        return members.joinToString(",\n") { (fieldName, type) ->
            val indent = "    "
            val typeJson = mapType(type, fieldName, psiClass.name ?: "", warnings, visited, depth)
            "$indent{\"name\": \"$fieldName\", \"type\": $typeJson}"
        }
    }

    private fun mapType(
        type: PsiType,
        fieldName: String,
        ownerName: String,
        warnings: MutableList<String>,
        visited: MutableSet<String>,
        depth: Int
    ): String {
        // Primitives
        when (type) {
            PsiTypes.intType() -> return "\"int\""
            PsiTypes.longType() -> return "\"long\""
            PsiTypes.doubleType() -> return "\"double\""
            PsiTypes.floatType() -> return "\"float\""
            PsiTypes.booleanType() -> return "\"boolean\""
            else -> {}
        }

        val classType = type as? PsiClassType
        val resolved = classType?.resolve()
        val qName = resolved?.qualifiedName ?: type.canonicalText

        return when (qName) {
            "java.lang.String" -> "\"string\""
            "java.lang.Integer" -> nullableWarn("int", fieldName, warnings)
            "java.lang.Long" -> nullableWarn("long", fieldName, warnings)
            "java.lang.Double" -> nullableWarn("double", fieldName, warnings)
            "java.lang.Float" -> nullableWarn("float", fieldName, warnings)
            "java.lang.Boolean" -> nullableWarn("boolean", fieldName, warnings)

            "java.math.BigDecimal" -> {
                warnings += "Field '$fieldName' in $ownerName: BigDecimal mapped to bytes/decimal with " +
                        "placeholder precision=18, scale=2 -- CONFIRM correct precision/scale for your domain."
                "{\"type\": \"bytes\", \"logicalType\": \"decimal\", \"precision\": 18, \"scale\": 2}"
            }

            "java.time.Instant", "java.time.LocalDateTime", "java.util.Date" -> {
                warnings += "Field '$fieldName' in $ownerName: $qName mapped to long/timestamp-millis -- " +
                        "confirm timezone handling is acceptable (Avro timestamps are UTC millis)."
                "{\"type\": \"long\", \"logicalType\": \"timestamp-millis\"}"
            }

            "java.time.LocalDate" -> "{\"type\": \"int\", \"logicalType\": \"date\"}"

            "java.util.UUID" -> "{\"type\": \"string\", \"logicalType\": \"uuid\"}"

            "java.util.Optional" -> {
                val inner = classType?.parameters?.firstOrNull()
                val innerJson = if (inner != null) mapType(inner, fieldName, ownerName, warnings, visited, depth) else "\"string\""
                warnings += "Field '$fieldName' in $ownerName: Optional<T> mapped to nullable union -- verify default null is correct."
                "[\"null\", $innerJson]"
            }

            "java.util.List", "java.util.Set", "java.util.Collection" -> {
                val inner = classType?.parameters?.firstOrNull()
                val innerJson = if (inner != null) mapType(inner, fieldName, ownerName, warnings, visited, depth) else run {
                    warnings += "Field '$fieldName' in $ownerName: raw collection type, defaulting item type to string -- please fix."
                    "\"string\""
                }
                "{\"type\": \"array\", \"items\": $innerJson}"
            }

            "java.util.Map" -> {
                val valueType = classType?.parameters?.getOrNull(1)
                val valueJson = if (valueType != null) mapType(valueType, fieldName, ownerName, warnings, visited, depth) else "\"string\""
                warnings += "Field '$fieldName' in $ownerName: Map assumes String keys (Avro maps require string keys) -- verify."
                "{\"type\": \"map\", \"values\": $valueJson}"
            }

            else -> {
                if (resolved != null && resolved.isEnum) {
                    val symbols = resolved.fields
                        .filterIsInstance<PsiEnumConstant>()
                        .joinToString(", ") { "\"${it.name}\"" }
                    warnings += "Field '$fieldName' in $ownerName: Java enum mapped to Avro enum -- adding new symbols later " +
                            "is NOT safe under all compatibility modes; consider mapping to \"string\" instead if values change often."
                    "{\"type\": \"enum\", \"name\": \"${resolved.name}\", \"symbols\": [$symbols]}"
                } else if (resolved != null && isProjectDomainClass(resolved)) {
                    if (depth >= 4 || resolved.qualifiedName in visited) {
                        warnings += "Field '$fieldName' in $ownerName: nested type '${resolved.name}' skipped " +
                                "(depth limit or cyclic reference) -- inline manually."
                        "\"string\""
                    } else {
                        resolved.qualifiedName?.let { visited.add(it) }
                        val nestedFields = buildFieldsJson(resolved, warnings, visited, depth + 1)
                        val nestedNamespace = resolved.qualifiedName?.substringBeforeLast('.', "") ?: ""
                        buildString {
                            append("{\n")
                            append("      \"type\": \"record\",\n")
                            append("      \"name\": \"${resolved.name}\",\n")
                            if (nestedNamespace.isNotBlank()) append("      \"namespace\": \"$nestedNamespace\",\n")
                            append("      \"fields\": [\n")
                            append(nestedFields)
                            append("\n      ]\n")
                            append("    }")
                        }
                    }
                } else {
                    warnings += "Field '$fieldName' in $ownerName: unrecognized type '$qName', defaulted to \"string\" -- REVIEW REQUIRED."
                    "\"string\""
                }
            }
        }
    }

    private fun nullableWarn(baseType: String, fieldName: String, warnings: MutableList<String>): String {
        warnings += "Field '$fieldName': boxed type detected -- mapped as required \"$baseType\". " +
                "If this field can be null in practice, change to [\"null\", \"$baseType\"] with a default."
        return "\"$baseType\""
    }

    private fun isProjectDomainClass(psiClass: PsiClass): Boolean {
        val qName = psiClass.qualifiedName ?: return false
        val excludedPrefixes = listOf("java.", "javax.", "jakarta.", "org.apache.kafka.", "io.smallrye.", "io.vertx.")
        return excludedPrefixes.none { qName.startsWith(it) }
    }
}

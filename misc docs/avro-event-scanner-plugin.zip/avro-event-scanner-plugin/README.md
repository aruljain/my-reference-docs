# Avro Event Scanner (IntelliJ Plugin)

Scans a Java/Quarkus project for Kafka event **payload classes**, detected
structurally (not by naming convention or custom annotations), and generates
draft `.avsc` Avro schema files for each one.

## How detection works

No naming conventions or annotations required on your domain classes. Instead,
the plugin looks at real Kafka/Reactive-Messaging touchpoints and extracts the
payload type from them:

- `@Incoming` / `@Outgoing` annotated methods (SmallRye Reactive Messaging)
- `Emitter<T>` / `MutinyEmitter<T>` fields (typically paired with `@Channel`)
- `KafkaProducer<K,V>` / `KafkaConsumer<K,V>` usage (fields, params, locals)
- `ProducerRecord<K,V>` / `ConsumerRecord<K,V>` usage

Wrapper generics (`Message<T>`, `Uni<T>`, `Multi<T>`, `List<T>`, `Optional<T>`,
`CompletionStage<T>`) are automatically unwrapped to find the real domain type.

## Running it

1. Open this project in IntelliJ IDEA (Community or Ultimate).
2. Run `./gradlew runIde` — this launches a sandboxed IDE instance with the
   plugin installed.
3. In that sandbox IDE, open **your** Quarkus project.
4. Go to **Tools → Generate Avro Schemas from Kafka Events**.
5. Draft `.avsc` files are written to `src/main/avro/` in your project, and a
   summary dialog lists every class found plus review flags.

## IMPORTANT: generated schemas are drafts, not final answers

The plugin will flag (in the summary dialog) any decision it had to guess at:

- Boxed types (`Integer`, `Long`, etc.) are mapped as **required** fields —
  if the field can actually be `null`, you need to change it to a
  `["null", "..."]` union with a default.
- `BigDecimal` fields get a placeholder `precision`/`scale` — confirm the
  real values for your domain (money fields especially).
- `Instant` / `Date` / `LocalDateTime` fields assume UTC millis semantics.
- Java `enum` fields are mapped to Avro `enum` — this is only safe under
  compatibility rules if you never add new enum symbols; consider using
  `"string"` instead if the set of values changes often.
- Any field type the generator doesn't recognize is defaulted to `"string"`
  and flagged for manual fixing.

**Do not register these directly against a shared/production registry without
reviewing every warning first.** Treat the output the same way you'd treat a
first-pass code generation: correct shape, needs a human pass for semantics.

## Known limitations (roadmap ideas)

- Lombok-generated fields are read directly from the source `@Data`/`@Value`
  annotated class fine (since it reads declared fields, not generated
  bytecode), but Lombok `@Builder`-only DTOs with no field defaults won't
  surface default-value intent.
- Records are supported (`recordComponents`), but compact constructors with
  validation logic aren't inspected for nullability hints.
- Nested project-defined types are inlined as nested records up to a depth
  of 4; deeper graphs or cyclic references fall back to `"string"` with a
  warning rather than infinite-looping.
- This does not currently talk to Apicurio Registry directly (no
  auto-register-on-generate) — intentionally, so a human reviews the draft
  before anything is registered. That registration step belongs in your
  CI pipeline or a manual `curl`/Maven step, as discussed separately.

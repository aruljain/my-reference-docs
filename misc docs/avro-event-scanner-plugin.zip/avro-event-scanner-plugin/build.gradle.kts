plugins {
    id("java")
    id("org.jetbrains.kotlin.jvm") version "1.9.24"
    id("org.jetbrains.intellij.platform") version "2.1.0"
}

group = "com.yourcompany"
version = "0.1.0"

repositories {
    mavenCentral()
    intellijPlatform {
        defaultRepositories()
    }
}

dependencies {
    intellijPlatform {
        // Target IntelliJ IDEA Community, matches most Quarkus/Java dev setups.
        // Bump the version to whatever your team's IDE version is.
        create("IC", "2024.2")

        // Needed for Java PSI (PsiClass, PsiField, PsiMethod, etc.)
        bundledPlugin("com.intellij.java")

        instrumentationTools()
    }
}

kotlin {
    jvmToolchain(17)
}

intellijPlatform {
    pluginConfiguration {
        ideaVersion {
            sinceBuild.set("242")
        }
    }
}

tasks {
    wrapper {
        gradleVersion = "8.9"
    }
}
